package com.example.futureapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
