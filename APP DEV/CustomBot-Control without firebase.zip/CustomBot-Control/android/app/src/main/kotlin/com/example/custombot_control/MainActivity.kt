package com.example.custombot_control

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
